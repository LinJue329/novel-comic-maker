#!/usr/bin/env python3
"""
compose_page.py — 把原始插画合成成品漫画页

用法：
    python compose_page.py --input raw/p001.png --output final/p001.png \
        --text "我只比妹妹早出生五分钟。" --page 1 --book "入骨寒心"

输出：1080x1440 (3:4) 成品页，包含：
  - 米色外框背景
  - 顶部圆角文本框（自动换行）
  - 右下角小字号页码
  - 左下角书名/作者署名
"""

import argparse
import os
import sys
from PIL import Image, ImageDraw, ImageFont

# ===== 画布与配色常量（参考官方样图）=====
CANVAS_W = 1080
CANVAS_H = 1440

BG_COLOR = (245, 239, 224)        # 米色外框 #F5EFE0
FRAME_COLOR = (58, 58, 58)        # 内框细线 #3A3A3A
TEXTBOX_BG = (255, 255, 255)      # 文本框白底
TEXT_COLOR = (44, 62, 80)          # 旁白文字深蓝灰 #2C3E50
META_COLOR = (90, 90, 90)         # 页码/署名灰色

# 边距
MARGIN_X = 50
MARGIN_TOP = 60
MARGIN_BOTTOM = 50

# 文本框
TEXTBOX_PAD_X = 28
TEXTBOX_PAD_Y = 18
TEXTBOX_RADIUS = 14
TEXT_FONT_SIZE = 36
TEXT_LINE_GAP = 10
TEXTBOX_INSET_X = 35   # 文本框距内框左右
TEXTBOX_INSET_TOP = 25 # 文本框距内框顶部

# 页码 / 署名
PAGE_FONT_SIZE = 20          # 小字号，不抢戏
SIGN_FONT_SIZE = 24
PAGE_MARGIN_RIGHT = 30       # 右下角页码
PAGE_MARGIN_BOTTOM = 12
SIGN_MARGIN_LEFT = 30
SIGN_MARGIN_BOTTOM = 12


def find_chinese_font():
    """跨平台找一个可用的中文字体。"""
    system = sys.platform

    if system == "win32":
        candidates = [
            r"C:\Windows\Fonts\msyh.ttc",      # 微软雅黑
            r"C:\Windows\Fonts\msyhbd.ttc",    # 微软雅黑 Bold
            r"C:\Windows\Fonts\simhei.ttf",    # 黑体
            r"C:\Windows\Fonts\simsun.ttc",    # 宋体
        ]
    elif system == "darwin":
        candidates = [
            "/System/Library/Fonts/PingFang.ttc",          # 苹方
            "/System/Library/Fonts/STHeiti Light.ttc",     # 黑体-简
            "/Library/Fonts/Arial Unicode.ttf",            # Arial Unicode
        ]
    else:  # linux / other
        candidates = [
            "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
        ]

    for p in candidates:
        if os.path.exists(p):
            return p
    return None


def wrap_text(text, font, max_width, draw):
    """按像素宽度对中文文本做自动换行。"""
    lines = []
    current = ""
    for ch in text:
        test = current + ch
        bbox = draw.textbbox((0, 0), test, font=font)
        w = bbox[2] - bbox[0]
        if w > max_width and current:
            lines.append(current)
            current = ch
        else:
            current = test
    if current:
        lines.append(current)
    return lines


def rounded_rect(draw, xy, radius, fill, outline=None, width=1):
    """画圆角矩形。"""
    x0, y0, x1, y1 = xy
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def compose(input_path, output_path, text, page_num, book_name):
    # 1. 打开原始插画
    raw = Image.open(input_path).convert("RGB")

    # 2. 计算内框区域
    inner_x = MARGIN_X
    inner_y = MARGIN_TOP
    inner_w = CANVAS_W - MARGIN_X * 2
    inner_h = CANVAS_H - MARGIN_TOP - MARGIN_BOTTOM

    # 把原始插画等比缩放到内框大小（cover 模式，裁掉多余部分）
    src_ratio = raw.width / raw.height
    dst_ratio = inner_w / inner_h
    if src_ratio > dst_ratio:
        new_h = inner_h
        new_w = int(new_h * src_ratio)
    else:
        new_w = inner_w
        new_h = int(new_w / src_ratio)
    raw_resized = raw.resize((new_w, new_h), Image.LANCZOS)
    # 居中裁剪
    left = (new_w - inner_w) // 2
    top = (new_h - inner_h) // 2
    raw_cropped = raw_resized.crop((left, top, left + inner_w, top + inner_h))

    # 3. 创建米色画布
    canvas = Image.new("RGB", (CANVAS_W, CANVAS_H), BG_COLOR)

    # 4. 把裁剪好的插画贴到内框位置
    canvas.paste(raw_cropped, (inner_x, inner_y))

    draw = ImageDraw.Draw(canvas)

    # 5. 画内框细线
    draw.rectangle(
        [inner_x, inner_y, inner_x + inner_w, inner_y + inner_h],
        outline=FRAME_COLOR, width=2,
    )

    # 6. 加载字体
    font_path = find_chinese_font()
    if font_path is None:
        print("警告：找不到中文字体，文字可能乱码", file=sys.stderr)
        text_font = ImageFont.load_default()
        meta_font = ImageFont.load_default()
    else:
        text_font = ImageFont.truetype(font_path, TEXT_FONT_SIZE)
        meta_font = ImageFont.truetype(font_path, PAGE_FONT_SIZE)
        sign_font = ImageFont.truetype(font_path, SIGN_FONT_SIZE)

    # 7. 文本框（压在内框上部，偏左，宽度随文字自然伸缩）
    box_x_start = inner_x + TEXTBOX_INSET_X
    box_y0 = inner_y + TEXTBOX_INSET_TOP

    # 最大可用宽度（不撑满，留出呼吸感）
    max_text_w = inner_w - TEXTBOX_INSET_X * 2 - TEXTBOX_PAD_X * 2

    # 自动换行
    lines = wrap_text(text, text_font, max_text_w, draw)

    # 计算每行实际像素宽度和高度
    line_widths = []
    line_heights = []
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=text_font)
        line_widths.append(bbox[2] - bbox[0])
        line_heights.append(bbox[3] - bbox[1])

    # 文本框实际宽度 = 最长行文字 + 左右padding，不撑满
    actual_text_w = max(line_widths) if line_widths else 0
    box_x0 = box_x_start
    box_x1 = box_x0 + actual_text_w + TEXTBOX_PAD_X * 2

    # 文本框高度
    text_block_h = sum(line_heights) + TEXT_LINE_GAP * (len(lines) - 1)
    box_y1 = box_y0 + TEXTBOX_PAD_Y * 2 + text_block_h

    # 画圆角文本框
    rounded_rect(
        draw,
        [box_x0, box_y0, box_x1, box_y1],
        radius=TEXTBOX_RADIUS,
        fill=TEXTBOX_BG,
        outline=FRAME_COLOR,
        width=2,
    )

    # 逐行写文字
    cy = box_y0 + TEXTBOX_PAD_Y
    for i, line in enumerate(lines):
        draw.text(
            (box_x0 + TEXTBOX_PAD_X, cy),
            line,
            fill=TEXT_COLOR,
            font=text_font,
        )
        cy += line_heights[i] + TEXT_LINE_GAP

    # 8. 右下角小字号页码（三位数字）
    page_str = f"{int(page_num):03d}"
    draw.text(
        (CANVAS_W - PAGE_MARGIN_RIGHT, CANVAS_H - PAGE_MARGIN_BOTTOM),
        page_str,
        fill=META_COLOR,
        font=meta_font,
        anchor="rb",
    )

    # 9. 左下角书名/作者署名
    if book_name:
        draw.text(
            (SIGN_MARGIN_LEFT, CANVAS_H - SIGN_MARGIN_BOTTOM),
            book_name,
            fill=META_COLOR,
            font=sign_font,
            anchor="lb",
        )

    # 10. 保存
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    canvas.save(output_path, "PNG", quality=95)
    print(f"✅ 已生成: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="把原始插画合成成品漫画页")
    parser.add_argument("--input", required=True, help="原始插画路径")
    parser.add_argument("--output", required=True, help="成品页输出路径")
    parser.add_argument("--text", required=True, help="旁白文案")
    parser.add_argument("--page", required=True, type=int, help="页码（整数）")
    parser.add_argument("--book", default="", help="左下角署名（书名/作者）")
    args = parser.parse_args()

    compose(args.input, args.output, args.text, args.page, args.book)


if __name__ == "__main__":
    main()
